package com.example.android_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
